<?php
/***************************************

## Theme URI: http://www.chenxingweb.com/cx-udy-auto-gaoji-user.html
## Author: 晨星博客
## Author URI: http://www.chenxingweb.com
## Description: 简洁时尚自适应图片主题，适合各种图片展示类网站，有问题请加QQ群565616228请求帮助。
## Theme Name: CX-UDY
## Version: 0.3

****************************************/
wp_get_header(); ?>

<div class="main cw_35399">
  <div class="main_inner" style="margin-top: 90px;text-align:center">
  <div class="error-404" style="font-size: 15em;color: #F66;">404</div>
  <div style="font-size:16px;background-color: #F66;display: block;width: 100%;max-width: 350px;margin: 0 auto;height: 50px;line-height: 50px;color: #fff;border-radius: 10px;text-shadow: 1px 1px 2px #000;margin-bottom: 70px;">您访问的页面不存在！<br><br><br></div>
  </div>
</div>

<?php get_footer(); ?>
