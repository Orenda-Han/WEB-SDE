<?php
/***************************************

## Theme URI: http://www.chenxingweb.com/cx-udy-auto-gaoji-user.html
## Author: 晨星博客
## Author URI: http://www.chenxingweb.com
## Description: 简洁时尚自适应图片主题，适合各种图片展示类网站，有问题请加QQ群565616228请求帮助。
## Theme Name: CX-UDY
## Version: 0.3

****************************************/
wp_get_header();
global $wp_query;
$cat_name = $wp_query->query_vars['category_name'];
$cat_ob =get_category_by_slug($cat_name);
$cat = $cat_ob->term_id;

do_action('cat_chen_archive',$cat);

/** 掉用公共底部 **/
get_footer();