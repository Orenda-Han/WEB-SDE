<?php
/***************************************

## Theme URI: http://www.chenxingweb.com/cx-udy-auto-gaoji-user.html
## Author: 晨星博客
## Author URI: http://www.chenxingweb.com
## Description: 简洁时尚自适应图片主题，适合各种图片展示类网站，有问题请加QQ群565616228请求帮助。
## Theme Name: CX-UDY
## Version: 0.3

****************************************/
wp_get_header();

/** 分类公共代码 **/
$tags_id = get_tags();
$tags_id = $tags_id[0]->term_id;

do_action('tag_chen_archive',$tags_id);

/** 掉用公共底部 **/
get_footer();